#pragma once
// ============================================================
//  data_preprocessing.h
//  Mirrors: data_preprocessing.py
//  Purpose: Load, clean, merge CSV ride datasets
// ============================================================

#include <vector>
#include <string>
#include <iostream>

// ── Ride Struct ──────────────────────────────────────────────
// Equivalent to the Ride object in Python preprocessing
struct Ride {
    double pickup_lat;   // Latitude  of pickup  point
    double pickup_lon;   // Longitude of pickup  point
    double drop_lat;     // Latitude  of drop    point
    double drop_lon;     // Longitude of drop    point
    int    ride_id;      // Unique identifier for this ride
};

// ── Function Declarations ────────────────────────────────────

/* Load a single CSV file; returns vector of Ride structs
   CSV must have header: pickup_lat,pickup_lon,drop_lat,drop_lon */
std::vector<Ride> loadCSV(const std::string& filename);

/* Validate one ride — checks coordinate ranges & non-zero */
bool isValidRide(const Ride& r);

/* Remove invalid rows + duplicates (mirrors Python cleanData) */
std::vector<Ride> cleanData(std::vector<Ride> rides);

/* Load and merge multiple CSV files into one vector of Rides */
std::vector<Ride> mergeDatasets(const std::vector<std::string>& files);

/* Save cleaned/processed rides to a CSV file */
void saveProcessedData(const std::vector<Ride>& rides,
                        const std::string& filename);

/* Reload previously saved processed_data.csv */
std::vector<Ride> loadProcessedData(const std::string& filename);
