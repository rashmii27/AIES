#pragma once
// ============================================================
//  train_test.h
//  Mirrors: train_test.py
//  Purpose: Train-test split, graph construction, algorithms
// ============================================================

#include "data_preprocessing.h"
#include <vector>
#include <utility>
#include <string>

// ── Graph Type ───────────────────────────────────────────────
// Adjacency list: graph[u] = list of (neighbor_node, dist*10000)
// Distance is scaled to int to avoid float precision issues
using Graph = std::vector<std::vector<std::pair<int, int>>>;

// ── Structs ──────────────────────────────────────────────────

/* A geographic location (lat/lon pair) representing a graph node */
struct Location {
    double lat;
    double lon;
};

/* A route: ordered sequence of node indices + total distance */
struct Route {
    std::vector<int> path;     // node indices in visit order
    double           distance; // total Euclidean distance (degrees)
    double           eta_min;  // estimated travel time (minutes)
};

/* Two rides matched together for carpooling */
struct MatchedRide {
    int    ride1_id;
    int    ride2_id;
    double pickup_distance; // Euclidean distance between pickups
};

/* Driver assigned to a matched ride pair */
struct Driver {
    int    driver_id;
    int    ride1_id;
    int    ride2_id;
    double assigned_at; // simulation timestamp (seconds)
};

// ── Utility ──────────────────────────────────────────────────

/* Euclidean distance between two Location nodes */
double euclidean(const Location& a, const Location& b);

/* ETA in minutes given Euclidean distance in degrees
   Assumes 1 degree ≈ 111 km, average speed 30 km/h */
double calculateETA(double distance);

// ── Train / Test Split ────────────────────────────────────────

/* Shuffle then split rides 80% train / 20% test (mirrors Python split) */
void trainTestSplit(const std::vector<Ride>& data,
                    std::vector<Ride>&       train,
                    std::vector<Ride>&       test,
                    double test_ratio = 0.2);

// ── Graph Construction ─────────────────────────────────────────

/* Extract unique locations (nodes) from rides (pickup + drop) */
std::vector<Location> extractLocations(const std::vector<Ride>& rides);

/* Build complete-graph adjacency list from location nodes */
Graph buildGraph(const std::vector<Location>& locations);

// ── Algorithm A: Dijkstra ──────────────────────────────────────

/* Shortest path from source → target node (returns node-index path) */
std::vector<int> dijkstra(const Graph& graph, int source, int target);

// ── Algorithm B: Greedy Ride Matching ─────────────────────────

/* Match nearby rides for carpooling; minimize pickup distance */
std::vector<MatchedRide> greedyRideMatching(
    const std::vector<Ride>&     rides,
    const std::vector<Location>& locations);

// ── Algorithm C: TSP Nearest Neighbor ─────────────────────────

/* Approximate optimal pickup/drop sequence via nearest-neighbor heuristic */
Route tspNearestNeighbor(const std::vector<Location>& locations,
                          const std::vector<int>&      nodeIndices);

// ── Bonus: Driver Assignment ────────────────────────────────────

/* Assign a driver to each matched ride pair */
std::vector<Driver> assignDrivers(const std::vector<MatchedRide>& matches);

// ── Bonus: Ride Request Simulation ─────────────────────────────

/* Simulate incoming ride requests from test set */
void simulateRideRequests(const std::vector<Ride>& test_rides, int count = 5);

// ── Output ─────────────────────────────────────────────────────

/* Save result.json in required format for the frontend */
void saveResultJSON(const std::vector<Route>&       routes,
                    const std::vector<MatchedRide>& matches,
                    const std::vector<Driver>&      drivers,
                    const std::vector<Location>&    locations,
                    const std::vector<Ride>&        all_rides,
                    const std::string&              filename);
