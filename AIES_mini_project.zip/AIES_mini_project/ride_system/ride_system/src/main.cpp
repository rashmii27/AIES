// ============================================================
//  src/main.cpp
//  Mirrors: app.py
//
//  Main entry point — runs the full Ride Sharing & Fleet
//  Optimisation pipeline:
//
//    1. Load datasets from data/
//    2. Clean & merge (data_preprocessing)
//    3. Split 80/20 train-test
//    4. Build graph
//    5. Dijkstra  — shortest paths for test rides
//    6. Greedy    — carpool ride matching
//    7. TSP       — optimised multi-stop route
//    8. Simulate  — ride request stream (bonus)
//    9. Assign    — driver allocation (bonus)
//   10. Output    — output/result.json for the frontend
// ============================================================

#include "../include/data_preprocessing.h"
#include "../include/train_test.h"

#include <iostream>
#include <vector>
#include <string>
#include <cmath>
#include <algorithm>
#include <iomanip>

// ── Helper: find the graph node closest to a (lat, lon) ─────
static int nearestNode(const std::vector<Location>& locs,
                        double lat, double lon) {
    int    best = 0;
    double min_d = 1e18;
    for (int i = 0; i < (int)locs.size(); i++) {
        double d = std::sqrt(std::pow(locs[i].lat - lat, 2) +
                             std::pow(locs[i].lon - lon, 2));
        if (d < min_d) { min_d = d; best = i; }
    }
    return best;
}

// ── Helper: print a section banner ──────────────────────────
static void banner(const std::string& title) {
    std::cout << "\n" << std::string(55, '=') << std::endl;
    std::cout << "  " << title                  << std::endl;
    std::cout << std::string(55, '=') << std::endl;
}

// ============================================================
//  main()
// ============================================================
int main() {
    std::cout << std::endl;
    std::cout << "╔═══════════════════════════════════════════════════╗\n";
    std::cout << "║   RIDE SHARING & FLEET OPTIMISATION SYSTEM        ║\n";
    std::cout << "║   Algorithms: Dijkstra | Greedy | TSP             ║\n";
    std::cout << "╚═══════════════════════════════════════════════════╝\n";

    // ══════════════════════════════════════════════════════════
    //  STEP 1 — Load & merge datasets  (data_preprocessing.cpp)
    // ══════════════════════════════════════════════════════════
    banner("STEP 1 — Load & Merge Datasets");

    std::vector<std::string> data_files = {
        "data/rides_1.csv",
        "data/rides_2.csv"
        // Add more files here if needed:
        // "data/rides_3.csv"
    };

    std::vector<Ride> all_rides = mergeDatasets(data_files);

    if (all_rides.empty()) {
        std::cerr << "\n[ERROR] No rides loaded. "
                  << "Check that data/rides_1.csv exists.\n";
        return 1;
    }

    // ══════════════════════════════════════════════════════════
    //  STEP 2 — Save processed data  (mirrors df.to_csv())
    // ══════════════════════════════════════════════════════════
    banner("STEP 2 — Save Processed Data");

    saveProcessedData(all_rides, "processed_data.csv");

    std::cout << "\n  Feature matrix shape : "
              << all_rides.size() << " rides × 4 features\n";
    std::cout << "  Features: pickup_lat, pickup_lon, "
                 "drop_lat, drop_lon\n";

    // ══════════════════════════════════════════════════════════
    //  STEP 3 — Train / Test split  (train_test.cpp)
    // ══════════════════════════════════════════════════════════
    banner("STEP 3 — Train / Test Split (80% / 20%)");

    std::vector<Ride> train_rides, test_rides;
    trainTestSplit(all_rides, train_rides, test_rides, 0.2);

    // ══════════════════════════════════════════════════════════
    //  STEP 4 — Build graph from training data
    // ══════════════════════════════════════════════════════════
    banner("STEP 4 — Graph Construction");

    std::vector<Location> locations = extractLocations(train_rides);
    Graph                 graph     = buildGraph(locations);

    // ══════════════════════════════════════════════════════════
    //  STEP 5 — Algorithm A: Dijkstra shortest paths
    // ══════════════════════════════════════════════════════════
    banner("STEP 5 — Dijkstra Shortest Paths");

    std::vector<Route> routes;
    int dijkstra_count = std::min(5, (int)test_rides.size());

    std::cout << std::fixed << std::setprecision(4);
    for (int i = 0; i < dijkstra_count; i++) {
        const Ride& r   = test_rides[i];
        int src          = nearestNode(locations, r.pickup_lat, r.pickup_lon);
        int tgt          = nearestNode(locations, r.drop_lat,   r.drop_lon);

        std::vector<int> path = dijkstra(graph, src, tgt);

        if (!path.empty()) {
            // Compute actual distance along path
            double dist = 0.0;
            for (int k = 0; k + 1 < (int)path.size(); k++) {
                dist += euclidean(locations[path[k]], locations[path[k + 1]]);
            }
            double eta = calculateETA(dist);
            routes.push_back({ path, dist, eta });

            std::cout << "  Route #" << std::setw(2) << (i + 1)
                      << " : " << path.size() << " hops"
                      << "  dist=" << dist << "°"
                      << "  ETA≈" << std::setprecision(1) << eta << " min"
                      << std::setprecision(4) << std::endl;
        } else {
            std::cout << "  Route #" << (i + 1)
                      << " : No path found (isolated node)\n";
        }
    }

    // ══════════════════════════════════════════════════════════
    //  STEP 6 — Algorithm B: Greedy Ride Matching
    // ══════════════════════════════════════════════════════════
    banner("STEP 6 — Greedy Ride Matching (Carpool)");

    std::vector<MatchedRide> matches =
        greedyRideMatching(train_rides, locations);

    // ══════════════════════════════════════════════════════════
    //  STEP 7 — Algorithm C: TSP Nearest Neighbour
    // ══════════════════════════════════════════════════════════
    banner("STEP 7 — TSP Nearest Neighbour Route Optimisation");

    // Use first min(12, n) locations as TSP nodes
    int tsp_n = std::min(12, (int)locations.size());
    std::vector<int> tsp_nodes;
    for (int i = 0; i < tsp_n; i++) tsp_nodes.push_back(i);

    Route tsp_route = tspNearestNeighbor(locations, tsp_nodes);

    std::cout << "  TSP tour size    : " << tsp_route.path.size() << " stops\n";
    std::cout << "  Total distance   : " << std::fixed << std::setprecision(4)
              << tsp_route.distance << " degrees\n";
    std::cout << "  Estimated time   : " << std::setprecision(1)
              << tsp_route.eta_min << " minutes\n";

    // Print the tour sequence
    std::cout << "  Tour sequence    : ";
    for (int i = 0; i < (int)tsp_route.path.size(); i++) {
        int idx = tsp_route.path[i];
        std::cout << std::setprecision(3)
                  << "(" << locations[idx].lat
                  << "," << locations[idx].lon << ")";
        if (i + 1 < (int)tsp_route.path.size()) std::cout << " → ";
    }
    std::cout << " → (back to start)\n";

    routes.push_back(tsp_route); // add TSP tour to routes

    // ══════════════════════════════════════════════════════════
    //  STEP 8 — Bonus: Simulate ride request stream
    // ══════════════════════════════════════════════════════════
    banner("STEP 8 — Ride Request Simulation (BONUS)");

    simulateRideRequests(test_rides, 5);

    // ══════════════════════════════════════════════════════════
    //  STEP 9 — Bonus: Assign drivers to matched pairs
    // ══════════════════════════════════════════════════════════
    banner("STEP 9 — Driver Assignment (BONUS)");

    std::vector<Driver> drivers = assignDrivers(matches);

    // ══════════════════════════════════════════════════════════
    //  STEP 10 — Save output/result.json
    // ══════════════════════════════════════════════════════════
    banner("STEP 10 — Save JSON Output");

    saveResultJSON(routes, matches, drivers,
                   locations, all_rides,
                   "output/result.json");

    // ── Final Summary ────────────────────────────────────────
    std::cout << "\n";
    std::cout << "╔═══════════════════════════════════════════════════╗\n";
    std::cout << "║   ✅  Pipeline Complete!                          ║\n";
    std::cout << "╠═══════════════════════════════════════════════════╣\n";
    std::cout << "║  Total rides       : " << std::setw(5) << all_rides.size()
              << "                         ║\n";
    std::cout << "║  Training rides    : " << std::setw(5) << train_rides.size()
              << "                         ║\n";
    std::cout << "║  Test rides        : " << std::setw(5) << test_rides.size()
              << "                         ║\n";
    std::cout << "║  Graph nodes       : " << std::setw(5) << locations.size()
              << "                         ║\n";
    std::cout << "║  Dijkstra routes   : " << std::setw(5) << (routes.size()-1)
              << "                         ║\n";
    std::cout << "║  Matched pairs     : " << std::setw(5) << matches.size()
              << "                         ║\n";
    std::cout << "║  Drivers assigned  : " << std::setw(5) << drivers.size()
              << "                         ║\n";
    std::cout << "╠═══════════════════════════════════════════════════╣\n";
    std::cout << "║  processed_data.csv  → cleaned merged rides       ║\n";
    std::cout << "║  output/result.json  → routes + matches           ║\n";
    std::cout << "║  index.html          → open in browser (map UI)   ║\n";
    std::cout << "╚═══════════════════════════════════════════════════╝\n\n";

    return 0;
}
