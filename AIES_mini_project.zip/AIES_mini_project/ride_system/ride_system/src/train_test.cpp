// ============================================================
//  src/train_test.cpp
//  Mirrors: train_test.py
//
//  Steps:
//    1. Shuffle & split 80/20 train-test
//    2. Extract unique locations → graph nodes
//    3. Build adjacency-list graph (Euclidean edge weights)
//    4. Algorithm A: Dijkstra shortest path
//    5. Algorithm B: Greedy Ride Matching (carpooling)
//    6. Algorithm C: TSP Nearest Neighbor (route optimisation)
//    7. Bonus  : ETA, driver assignment, ride simulation
//    8. Output : output/result.json
// ============================================================

#include "../include/train_test.h"
#include <algorithm>
#include <random>
#include <queue>
#include <climits>
#include <cmath>
#include <fstream>
#include <map>
#include <set>
#include <iomanip>

// ============================================================
//  euclidean()
//  Standard 2-D Euclidean distance in (lat, lon) degree space.
//  NOTE: 1 degree ≈ 111 km — sufficient for city-scale routing.
// ============================================================
double euclidean(const Location& a, const Location& b) {
    double dlat = a.lat - b.lat;
    double dlon = a.lon - b.lon;
    return std::sqrt(dlat * dlat + dlon * dlon);
}

// ============================================================
//  calculateETA()
//  Convert Euclidean degree-distance → estimated travel minutes.
//  Formula: distance (degrees) × 111 km/deg ÷ 30 km/h × 60 min/h
// ============================================================
double calculateETA(double distance) {
    double km    = distance * 111.0;   // approximate km
    double hours = km / 30.0;          // 30 km/h urban average
    return hours * 60.0;               // convert to minutes
}

// ============================================================
//  trainTestSplit()
//  Shuffle rides (seed=42 for reproducibility), then split.
//  Mirrors: train_test_split(X, y, test_size=0.2, random_state=42)
// ============================================================
void trainTestSplit(const std::vector<Ride>& data,
                    std::vector<Ride>&       train,
                    std::vector<Ride>&       test,
                    double test_ratio) {
    // Copy so we can shuffle without mutating the original
    std::vector<Ride> shuffled = data;

    // Reproducible shuffle — seed 42 mirrors Python random_state=42
    std::mt19937 rng(42);
    std::shuffle(shuffled.begin(), shuffled.end(), rng);

    int test_size  = static_cast<int>(shuffled.size() * test_ratio);
    int train_size = static_cast<int>(shuffled.size()) - test_size;

    train = std::vector<Ride>(shuffled.begin(),
                              shuffled.begin() + train_size);
    test  = std::vector<Ride>(shuffled.begin() + train_size,
                              shuffled.end());

    std::cout << "\nSplitting into train / test sets (80% / 20%)" << std::endl;
    std::cout << "  Training set : " << train.size() << " rides" << std::endl;
    std::cout << "  Test set     : " << test.size()  << " rides" << std::endl;
}

// ============================================================
//  extractLocations()
//  Collect every unique (lat, lon) from rides — both pickup and
//  drop points become graph nodes.  Uses a map keyed on
//  (round-to-4-dp lat, round-to-4-dp lon) to deduplicate nearby
//  coordinates.
// ============================================================
std::vector<Location> extractLocations(const std::vector<Ride>& rides) {
    // Key: (lat*10000, lon*10000) so 4 decimal places ≈ 11 m
    std::map<std::pair<long long, long long>, int> seen;
    std::vector<Location> locations;

    auto key = [](double lat, double lon)
        -> std::pair<long long, long long> {
        return { (long long)(lat * 10000),
                 (long long)(lon * 10000) };
    };

    for (const auto& r : rides) {
        auto pk = key(r.pickup_lat, r.pickup_lon);
        auto dk = key(r.drop_lat,   r.drop_lon);

        if (seen.find(pk) == seen.end()) {
            seen[pk] = (int)locations.size();
            locations.push_back({ r.pickup_lat, r.pickup_lon });
        }
        if (seen.find(dk) == seen.end()) {
            seen[dk] = (int)locations.size();
            locations.push_back({ r.drop_lat, r.drop_lon });
        }
    }

    return locations;
}

// ============================================================
//  buildGraph()
//  Construct a complete undirected weighted graph.
//  Nodes  = unique location indices
//  Edges  = Euclidean distance × 10000 (stored as int in pair)
//  Type   : vector<vector<pair<int,int>>>  (as required)
// ============================================================
Graph buildGraph(const std::vector<Location>& locations) {
    int   n = (int)locations.size();
    Graph graph(n);

    // Connect every pair of nodes (complete graph)
    for (int i = 0; i < n; i++) {
        for (int j = i + 1; j < n; j++) {
            // Scale float distance to int: multiply by 10 000
            // so 0.0001 degree ≈ 11 m maps to weight = 1
            int w = (int)(euclidean(locations[i], locations[j]) * 10000.0);
            if (w == 0) w = 1; // minimum weight 1

            graph[i].push_back({ j, w });
            graph[j].push_back({ i, w });
        }
    }

    // Print summary
    int total_edges = 0;
    for (const auto& adj : graph) total_edges += (int)adj.size();
    std::cout << "\nGraph Construction:" << std::endl;
    std::cout << "  Nodes (unique locations) : " << n                    << std::endl;
    std::cout << "  Edges (undirected pairs) : " << total_edges / 2      << std::endl;

    return graph;
}

// ============================================================
//  dijkstra()
//  Classic priority-queue Dijkstra.
//  Returns vector of node indices from source → target.
//  If no path exists, returns empty vector.
// ============================================================
std::vector<int> dijkstra(const Graph& graph, int source, int target) {
    int n = (int)graph.size();

    std::vector<int> dist(n, INT_MAX);  // shortest distance to each node
    std::vector<int> prev(n, -1);       // predecessor array for path trace

    // Min-heap: (distance, node)
    std::priority_queue<
        std::pair<int, int>,
        std::vector<std::pair<int, int>>,
        std::greater<std::pair<int, int>>
    > pq;

    dist[source] = 0;
    pq.push({ 0, source });

    while (!pq.empty()) {
        auto [d, u] = pq.top();
        pq.pop();

        if (d > dist[u]) continue;  // stale entry — skip
        if (u == target) break;     // found target — stop early

        for (const auto& [v, w] : graph[u]) {
            if (dist[u] + w < dist[v]) {
                dist[v] = dist[u] + w;
                prev[v] = u;
                pq.push({ dist[v], v });
            }
        }
    }

    // ── Reconstruct path by following prev[] back from target ─
    std::vector<int> path;
    if (dist[target] == INT_MAX) return path;  // unreachable

    for (int v = target; v != -1; v = prev[v]) {
        path.push_back(v);
    }
    std::reverse(path.begin(), path.end());
    return path;
}

// ============================================================
//  greedyRideMatching()
//  For each unmatched ride, find the nearest unmatched ride
//  by pickup-to-pickup Euclidean distance.
//  Pairs within threshold (0.05°≈5km) are matched for pooling.
//  Mirrors: greedy pooling / ride-matching logic in Python.
// ============================================================
std::vector<MatchedRide> greedyRideMatching(
        const std::vector<Ride>&     rides,
        const std::vector<Location>& /*locations*/) {

    std::cout << "\nRunning Greedy Ride Matching..." << std::endl;

    const double POOL_THRESHOLD = 0.05; // degrees ≈ 5.5 km

    std::vector<MatchedRide> matched;
    std::vector<bool> used(rides.size(), false);

    for (int i = 0; i < (int)rides.size(); i++) {
        if (used[i]) continue;

        double best_dist = 1e18;
        int    best_j    = -1;

        // Scan all later unmatched rides for the nearest pickup
        for (int j = i + 1; j < (int)rides.size(); j++) {
            if (used[j]) continue;

            double d = std::sqrt(
                std::pow(rides[i].pickup_lat - rides[j].pickup_lat, 2) +
                std::pow(rides[i].pickup_lon - rides[j].pickup_lon, 2)
            );

            if (d < best_dist) {
                best_dist = d;
                best_j    = j;
            }
        }

        // Match if within carpooling threshold
        if (best_j != -1 && best_dist <= POOL_THRESHOLD) {
            matched.push_back({
                rides[i].ride_id,
                rides[best_j].ride_id,
                best_dist
            });
            used[i]      = true;
            used[best_j] = true;
        }
    }

    std::cout << "  Matched " << matched.size()
              << " ride pairs for carpooling" << std::endl;
    return matched;
}

// ============================================================
//  tspNearestNeighbor()
//  Approximate solution to Travelling Salesman Problem using
//  the nearest-neighbour greedy heuristic:
//    1. Start at node nodeIndices[0]
//    2. At each step, move to the nearest unvisited node
//    3. Return to start to close the tour
//  Used to optimise multi-stop pickup/drop sequences.
// ============================================================
Route tspNearestNeighbor(const std::vector<Location>& locations,
                          const std::vector<int>&      nodeIndices) {
    if (nodeIndices.empty()) return { {}, 0.0, 0.0 };

    int m = (int)nodeIndices.size();
    std::vector<bool> visited(m, false);
    std::vector<int>  tour;
    double total_dist = 0.0;

    // ── Step 1: Start at first node ───────────────────────────
    int current = 0;
    tour.push_back(nodeIndices[0]);
    visited[0] = true;

    // ── Step 2: Greedily visit nearest unvisited ──────────────
    for (int step = 1; step < m; step++) {
        double min_d = 1e18;
        int    next  = -1;

        for (int i = 0; i < m; i++) {
            if (!visited[i]) {
                double d = euclidean(
                    locations[nodeIndices[current]],
                    locations[nodeIndices[i]]
                );
                if (d < min_d) {
                    min_d = d;
                    next  = i;
                }
            }
        }

        if (next == -1) break;

        total_dist += min_d;
        tour.push_back(nodeIndices[next]);
        visited[next] = true;
        current       = next;
    }

    // ── Step 3: Close tour — return to start ─────────────────
    if (tour.size() > 1) {
        total_dist += euclidean(
            locations[tour.back()],
            locations[tour.front()]
        );
    }

    return { tour, total_dist, calculateETA(total_dist) };
}

// ============================================================
//  assignDrivers()  [BONUS]
//  Create a Driver entry for each matched ride pair.
//  In a real system this would query a driver pool; here we
//  simulate it with sequential driver IDs and timestamps.
// ============================================================
std::vector<Driver> assignDrivers(const std::vector<MatchedRide>& matches) {
    std::cout << "\nDriver Assignment:" << std::endl;
    std::vector<Driver> drivers;

    for (int i = 0; i < (int)matches.size(); i++) {
        Driver d;
        d.driver_id    = i + 1;
        d.ride1_id     = matches[i].ride1_id;
        d.ride2_id     = matches[i].ride2_id;
        d.assigned_at  = i * 2.5; // simulated seconds offset

        drivers.push_back(d);

        std::cout << "  Driver D-" << std::setw(3) << std::setfill('0') << d.driver_id
                  << " → rides #" << d.ride1_id << " & #" << d.ride2_id
                  << "  (pickup gap: "
                  << std::fixed << std::setprecision(4)
                  << matches[i].pickup_distance << "°)" << std::endl;
    }
    return drivers;
}

// ============================================================
//  simulateRideRequests()  [BONUS]
//  Print a live simulation of incoming ride requests from the
//  test set — mirrors real-time request stream in Uber/Ola.
// ============================================================
void simulateRideRequests(const std::vector<Ride>& test_rides, int count) {
    std::cout << "\nSimulating Ride Requests (from test set):" << std::endl;

    int show = std::min(count, (int)test_rides.size());
    for (int i = 0; i < show; i++) {
        const auto& r = test_rides[i];
        double dist = std::sqrt(
            std::pow(r.pickup_lat - r.drop_lat, 2) +
            std::pow(r.pickup_lon - r.drop_lon, 2)
        );
        double eta = calculateETA(dist);

        std::cout << std::fixed << std::setprecision(4);
        std::cout << "  Request #" << std::setw(2) << (i + 1)
                  << "  Pickup ("  << r.pickup_lat << ", " << r.pickup_lon << ")"
                  << "  →  Drop (" << r.drop_lat   << ", " << r.drop_lon   << ")"
                  << "  | dist=" << dist << "°"
                  << "  ETA≈"   << std::setprecision(1) << eta << " min" << std::endl;
    }
}

// ============================================================
//  saveResultJSON()
//  Write output/result.json in the required format:
//  {
//    "routes": [ { "path": [[lat,lon],...], "distance": f,
//                  "eta_minutes": f } ],
//    "matched_rides": N,
//    "drivers": [ {...} ],
//    "ride_markers": { "pickups": [...], "drops": [...] }
//  }
// ============================================================
void saveResultJSON(const std::vector<Route>&       routes,
                    const std::vector<MatchedRide>& matches,
                    const std::vector<Driver>&      drivers,
                    const std::vector<Location>&    locations,
                    const std::vector<Ride>&        all_rides,
                    const std::string&              filename) {

    // Create output directory if needed
#ifdef _WIN32
    system("if not exist output mkdir output");
#else
    system("mkdir -p output");
#endif

    std::ofstream file(filename);
    if (!file.is_open()) {
        std::cerr << "[ERROR] Cannot write " << filename << std::endl;
        return;
    }

    file << std::fixed << std::setprecision(6);

    file << "{\n";

    // ── routes ──────────────────────────────────────────────
    file << "  \"routes\": [\n";
    for (int r = 0; r < (int)routes.size(); r++) {
        file << "    {\n";
        file << "      \"path\": [";

        for (int i = 0; i < (int)routes[r].path.size(); i++) {
            int idx = routes[r].path[i];
            if (idx >= 0 && idx < (int)locations.size()) {
                file << "[" << locations[idx].lat
                     << ", " << locations[idx].lon << "]";
                if (i + 1 < (int)routes[r].path.size()) file << ", ";
            }
        }

        file << "],\n";
        file << "      \"distance\": "    << routes[r].distance  << ",\n";
        file << "      \"eta_minutes\": " << routes[r].eta_min   << "\n";
        file << "    }";
        if (r + 1 < (int)routes.size()) file << ",";
        file << "\n";
    }
    file << "  ],\n";

    // ── matched_rides count ─────────────────────────────────
    file << "  \"matched_rides\": " << (int)matches.size() << ",\n";

    // ── matched pairs detail ────────────────────────────────
    file << "  \"matched_pairs\": [\n";
    for (int i = 0; i < (int)matches.size(); i++) {
        file << "    { \"ride1\": " << matches[i].ride1_id
             << ", \"ride2\": "     << matches[i].ride2_id
             << ", \"pickup_gap\": "<< matches[i].pickup_distance << " }";
        if (i + 1 < (int)matches.size()) file << ",";
        file << "\n";
    }
    file << "  ],\n";

    // ── drivers ─────────────────────────────────────────────
    file << "  \"drivers\": [\n";
    for (int i = 0; i < (int)drivers.size(); i++) {
        file << "    { \"driver_id\": " << drivers[i].driver_id
             << ", \"ride1\": "         << drivers[i].ride1_id
             << ", \"ride2\": "         << drivers[i].ride2_id << " }";
        if (i + 1 < (int)drivers.size()) file << ",";
        file << "\n";
    }
    file << "  ],\n";

    // ── ride markers for the frontend map ───────────────────
    file << "  \"ride_markers\": {\n";

    file << "    \"pickups\": [";
    for (int i = 0; i < (int)all_rides.size(); i++) {
        file << "[" << all_rides[i].pickup_lat
             << ", " << all_rides[i].pickup_lon << "]";
        if (i + 1 < (int)all_rides.size()) file << ", ";
    }
    file << "],\n";

    file << "    \"drops\": [";
    for (int i = 0; i < (int)all_rides.size(); i++) {
        file << "[" << all_rides[i].drop_lat
             << ", " << all_rides[i].drop_lon << "]";
        if (i + 1 < (int)all_rides.size()) file << ", ";
    }
    file << "]\n";

    file << "  }\n";
    file << "}\n";

    std::cout << "\nResults saved → " << filename << std::endl;
}
