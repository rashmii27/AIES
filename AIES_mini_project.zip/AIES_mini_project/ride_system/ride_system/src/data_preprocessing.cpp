// ============================================================
//  src/data_preprocessing.cpp
//  Mirrors: data_preprocessing.py
//
//  Steps:
//    1. Load multiple CSVs from data/ folder
//    2. Validate & clean each ride (remove bad coords, duplicates)
//    3. Merge all datasets into one vector<Ride>
//    4. Save processed_data.csv
// ============================================================

#include "../include/data_preprocessing.h"
#include <fstream>
#include <sstream>
#include <set>
#include <tuple>
#include <cmath>
#include <algorithm>
#include <iomanip>

// ── Helper: trim whitespace from a string ───────────────────
static std::string trim(const std::string& s) {
    size_t start = s.find_first_not_of(" \t\r\n");
    size_t end   = s.find_last_not_of(" \t\r\n");
    return (start == std::string::npos) ? "" : s.substr(start, end - start + 1);
}

// ── Helper: check if a string is a valid number ─────────────
static bool isNumber(const std::string& s) {
    if (s.empty()) return false;
    try { std::stod(s); return true; }
    catch (...) { return false; }
}

// ============================================================
//  loadCSV()
//  Opens a CSV, skips the header, parses each row.
//  Uses only <fstream> and <sstream> — no external libraries.
// ============================================================
std::vector<Ride> loadCSV(const std::string& filename) {
    std::vector<Ride> rides;
    std::ifstream file(filename);

    if (!file.is_open()) {
        std::cerr << "  [WARN] Cannot open: " << filename << std::endl;
        return rides;
    }

    std::string line;
    std::getline(file, line); // skip header row

    int ride_id = 0;
    int skipped = 0;

    while (std::getline(file, line)) {
        line = trim(line);
        if (line.empty()) { skipped++; continue; }

        // Parse comma-separated tokens
        std::stringstream ss(line);
        std::string token;
        std::vector<std::string> tokens;

        while (std::getline(ss, token, ',')) {
            tokens.push_back(trim(token));
        }

        // Need at least 4 columns: pickup_lat, pickup_lon, drop_lat, drop_lon
        if (tokens.size() < 4) { skipped++; continue; }

        // Validate all four fields are numeric
        if (!isNumber(tokens[0]) || !isNumber(tokens[1]) ||
            !isNumber(tokens[2]) || !isNumber(tokens[3])) {
            skipped++;
            continue;
        }

        Ride r;
        r.pickup_lat = std::stod(tokens[0]);
        r.pickup_lon = std::stod(tokens[1]);
        r.drop_lat   = std::stod(tokens[2]);
        r.drop_lon   = std::stod(tokens[3]);
        r.ride_id    = ride_id++;

        rides.push_back(r);
    }

    std::cout << "  Loaded  " << rides.size()
              << " rides  (skipped " << skipped << " bad rows)  ← "
              << filename << std::endl;
    return rides;
}

// ============================================================
//  isValidRide()
//  Geographic bounds check + non-zero check.
//  Mirrors Python's isValidRide / cleanData filter.
// ============================================================
bool isValidRide(const Ride& r) {
    // Latitude must be in [-90, 90]
    if (r.pickup_lat < -90.0 || r.pickup_lat > 90.0) return false;
    if (r.drop_lat   < -90.0 || r.drop_lat   > 90.0) return false;

    // Longitude must be in [-180, 180]
    if (r.pickup_lon < -180.0 || r.pickup_lon > 180.0) return false;
    if (r.drop_lon   < -180.0 || r.drop_lon   > 180.0) return false;

    // Reject (0,0) — almost certainly a missing/null value
    if (r.pickup_lat == 0.0 && r.pickup_lon == 0.0) return false;
    if (r.drop_lat   == 0.0 && r.drop_lon   == 0.0) return false;

    // Reject rides where pickup == drop (no movement)
    double dlat = std::fabs(r.pickup_lat - r.drop_lat);
    double dlon = std::fabs(r.pickup_lon - r.drop_lon);
    if (dlat < 1e-6 && dlon < 1e-6) return false;

    return true;
}

// ============================================================
//  cleanData()
//  1. Remove rows with invalid coordinates
//  2. Remove duplicates using a set<tuple> (hashing approach)
//  Mirrors Python's cleaning section in data_preprocessing.py
// ============================================================
std::vector<Ride> cleanData(std::vector<Ride> rides) {
    std::cout << "\nCleaning data..." << std::endl;
    std::cout << "  Before cleaning : " << rides.size() << " rides" << std::endl;

    // ── Step 1: Remove invalid rides ──────────────────────────
    std::vector<Ride> valid;
    valid.reserve(rides.size());

    for (const auto& r : rides) {
        if (isValidRide(r)) {
            valid.push_back(r);
        }
    }
    std::cout << "  After validity  : " << valid.size() << " rides" << std::endl;

    // ── Step 2: Remove duplicates using a set ─────────────────
    // Key = (pickup_lat*1e5, pickup_lon*1e5, drop_lat*1e5, drop_lon*1e5)
    // Rounding to 5 decimal places ≈ 1 metre precision
    using Key = std::tuple<long long, long long, long long, long long>;
    std::set<Key> seen;
    std::vector<Ride> unique_rides;
    unique_rides.reserve(valid.size());

    for (auto& r : valid) {
        Key key = std::make_tuple(
            (long long)(r.pickup_lat * 1e5),
            (long long)(r.pickup_lon * 1e5),
            (long long)(r.drop_lat   * 1e5),
            (long long)(r.drop_lon   * 1e5)
        );

        if (seen.find(key) == seen.end()) {
            seen.insert(key);
            unique_rides.push_back(r);
        }
    }

    int removed_dups = (int)valid.size() - (int)unique_rides.size();
    std::cout << "  After dedup     : " << unique_rides.size()
              << " rides  (removed " << removed_dups << " duplicates)" << std::endl;

    return unique_rides;
}

// ============================================================
//  mergeDatasets()
//  Load all CSV files, concatenate, then clean the merged set.
//  Mirrors Python's merge block in data_preprocessing.py
// ============================================================
std::vector<Ride> mergeDatasets(const std::vector<std::string>& files) {
    std::cout << "\nLoading datasets..." << std::endl;

    std::vector<Ride> all_rides;

    for (const auto& f : files) {
        auto batch = loadCSV(f);
        all_rides.insert(all_rides.end(), batch.begin(), batch.end());
    }

    std::cout << "  Total before cleaning : " << all_rides.size() << std::endl;

    // Clean the merged set (handles cross-file duplicates too)
    auto cleaned = cleanData(all_rides);

    // Re-assign sequential ride_ids after merge
    for (int i = 0; i < (int)cleaned.size(); i++) {
        cleaned[i].ride_id = i;
    }

    std::cout << "\nMerge complete → " << cleaned.size() << " rides" << std::endl;
    return cleaned;
}

// ============================================================
//  saveProcessedData()
//  Write cleaned rides to processed_data.csv
//  Mirrors Python's df_merged.to_csv("processed_data.csv")
// ============================================================
void saveProcessedData(const std::vector<Ride>& rides,
                        const std::string& filename) {
    std::ofstream file(filename);
    if (!file.is_open()) {
        std::cerr << "  [ERROR] Cannot write to " << filename << std::endl;
        return;
    }

    // Header
    file << "pickup_lat,pickup_lon,drop_lat,drop_lon,ride_id\n";

    // Rows — fixed precision to match Python float output
    file << std::fixed << std::setprecision(6);
    for (const auto& r : rides) {
        file << r.pickup_lat << ","
             << r.pickup_lon << ","
             << r.drop_lat   << ","
             << r.drop_lon   << ","
             << r.ride_id    << "\n";
    }

    std::cout << "  Saved " << rides.size()
              << " rides → " << filename << std::endl;
}

// ============================================================
//  loadProcessedData()
//  Read back a previously saved processed_data.csv.
//  Used if you want to skip re-preprocessing.
// ============================================================
std::vector<Ride> loadProcessedData(const std::string& filename) {
    std::vector<Ride> rides;
    std::ifstream file(filename);

    if (!file.is_open()) {
        std::cerr << "  [ERROR] Cannot open " << filename << std::endl;
        return rides;
    }

    std::string line;
    std::getline(file, line); // skip header

    while (std::getline(file, line)) {
        line = trim(line);
        if (line.empty()) continue;

        std::stringstream ss(line);
        std::string token;
        std::vector<std::string> tokens;
        while (std::getline(ss, token, ',')) tokens.push_back(trim(token));

        if (tokens.size() < 5) continue;
        try {
            Ride r;
            r.pickup_lat = std::stod(tokens[0]);
            r.pickup_lon = std::stod(tokens[1]);
            r.drop_lat   = std::stod(tokens[2]);
            r.drop_lon   = std::stod(tokens[3]);
            r.ride_id    = std::stoi(tokens[4]);
            rides.push_back(r);
        } catch (...) {}
    }

    return rides;
}
